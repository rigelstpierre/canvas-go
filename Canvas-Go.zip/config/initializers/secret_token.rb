# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
CanvasGo::Application.config.secret_token = 'fbda613535e11b58b669c0001cbb6f6a6adab97782524bd0e6e87bce5f5b9132443b46dc2e0d1a2f276c3449005571bf31ca3235b7f1de9762c90620852f51be'
