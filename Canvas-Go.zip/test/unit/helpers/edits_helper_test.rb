require 'test_helper'

class EditsHelperTest < ActionView::TestCase
end
