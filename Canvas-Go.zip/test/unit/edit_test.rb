require 'test_helper'

class EditTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
